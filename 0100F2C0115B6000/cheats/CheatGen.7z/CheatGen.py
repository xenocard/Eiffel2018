'''
This is a idaPython script used for helping NS atmosphere cheat code production

This Script is Programmed by Eiffel2018
    Works in IDA PRO v7.5 up 
    Requirement: Python 3.9.x (with idapyswitch) and Keystone 
    Operate with a clean NSO (or main.elf) 


How to get the AOB pattern?
    First you need to run the python/cheatGen.py once.
    then move the cursor to the place where you want to hack, 
    Trun the type of command line below the output windows from IDC to Python
    type getAOB() onto the command line
    You will get the AOB pattern in the output windows

What commands can be used in this file?
    AOB(pattern) return the first search result
    AllOccur(pattern) or AllOccur(pattern,offset) return all the search results found
    AOB2(pattern1,offset) return the address of a BL/B function inside [pattern1 + offset]
    AOB2(pattern1,offset,pattern2) return the result of second search, inside the BL/B function found by pattern1 + offset (pattern11 may be an address or pattern)
    AOB3(pattern1,pattern2) return the nearest result of second search from the first search. pattern2 may be an offset or pattern

    AddCheat(cheatname,cheatnameInChinese=None,newOption=0,isSuggest=False) newOption is default 0, it can be 1 and 2 if you want a/b/c/d/e sub index (1 for new index, 2 for next index)

    HackAll(pattern,codes,offset=0,showRestoreCode=True,useButton=None,elseCode=None) hack all the pattern found
    Hack(pattern,codes,showRestoreCode=True,useButton=None,elseCode=None,returnCode=False) hack one the first searched result 
    CodeCave(cheatAddr, codes, showrestoreCodes=True, use_BL=True, returnCode=False) a code cave function with caller address 
    CodeFunc(listOfCaveFunctionCodes) a function build into master code without call
    
    Float2DWord(float) a function returns Hex Text of a float
    Value2DWord(int)  a function returns Hex Text of a 32-bit integer

Note: 
    This python script cannot be used in GDB since the search function is very slow
    However you can use on a NSO and then copy the output result (codes generated) into the GDB environment (press F2, paste and execute)

Files Path:
    Base Folder
    Base Folder > Sample CheatGen.py (this file)
    Base Folder > __python__  
    Base Folder > __python__  > cheatLib.py
    Base Folder > __python__  > clearCache.py
    Base Folder > __python__  > idahelper.py
    Base Folder > __python__  > markRegions64.py
    Base Folder > __python__  > uEngine.py (optional)
    Base Folder > AGameFolder  
    Base Folder > AGameFolder > main.elf.i64 
    Base Folder > AGameFolder > CheatGen.py <-- code yourself

'''
if 'GetBase' in dir(): ClearCache('cheatLib');ClearCache('idahelper')

import sys
sys.path.insert(1,'..\__python__') 
from cheatLib import *

PlayerAOB = 0x46abf28
JumpAOB = 0x471a7d0
SceneAOB = 0x4725058
StorageAOB = 0x471e6b8
SP_OFFSET = 0x13fc
if not isGDB():
    PlayerAOB=GetQword(GetADRP(AOB('08 ? ? F9 09 01 40 F9 2A 01 0A 8B')))
    JumpAOB=GetADRP(AOB('D3 ? ? F9 93 02 00 B5 F4 03 00 AA 00 2C 80 52'))
    SceneAOB=GetQword(GetADRP(AOB('08 ? ? F9 29 ? ? F9 14 01 40 F9 28 01 40 F9 00 49 40 B9 ? ? ? ? 88 16 42 F9 1F 01 00 EB 60 00 00 54 88 A2 51 39 08 FE 2F 37')))
    StorageAOB=GetQword(GetADRP(AOB('D6 ? ? F9 E1 03 15 2A')))
    SP_OFFSET=idc.get_operand_value(AOB3('? ? ? ? ? ? ? 91 74 02 08 8B 80 56 00 BD',-4),1)+0x74
    print('PlayerAOB = %s'%hex(PlayerAOB))
    print('JumpAOB = %s'%hex(JumpAOB))
    print('SceneAOB = %s'%hex(SceneAOB))
    print('StorageAOB = %s'%hex(StorageAOB))
    print('SP_OFFSET = %s'%hex(SP_OFFSET))

Player = [PlayerAOB,0x480]
SystemBlackboard = Player+[0x220 if GetBID()=='082CE09B06E33A12' else 0x228] # 220 in v1.0
LifeParam = SystemBlackboard+[0x2F8]
HP = LifeParam+[0x1830,0x8]
MaxHP = LifeParam+[0x1838,0x8]
Damage = LifeParam+[0x1840,0x8]
Miasma = LifeParam+[0x1848,0x8]
PlayerParam = SystemBlackboard+[0x3A8]
SP = PlayerParam+[SP_OFFSET]

Physics=SystemBlackboard+[0x50]
MainMatterRigidBody=Physics+[0x20,0x150] # 694E84
GameParameterTable=SystemBlackboard+[0xA8]
LODParam=SystemBlackboard+[0xB0]
ActiveCameraAlphaParam=SystemBlackboard+[0xC0]
Logic=SystemBlackboard+[0xD0]
ActorPositionCalculatorParam=SystemBlackboard+[0xE0]
AffiliationParam=SystemBlackboard+[0xF0]
AttentionReceiverParam=SystemBlackboard+[0x128]
BSAParam=SystemBlackboard+[0x158]
BuffParam=SystemBlackboard+[0x160]
ChemicalParam=SystemBlackboard+[0x180]
ConditionParam=SystemBlackboard+[0x1A8]
DeathParam=SystemBlackboard+[0x1C8]
Blur=SystemBlackboard+[0x218]
EquipmentUserParam=SystemBlackboard+[0x230]
EventColorVariationParam=SystemBlackboard+[0x238]
GameBalanceClientParam=SystemBlackboard+[0x260]
LifeParam=SystemBlackboard+[0x2F8]
LifterParam=SystemBlackboard+[0x308]
PathFindingParam=SystemBlackboard+[0x370]
PerceptionEmitterParam=SystemBlackboard+[0x378]
PerimeterAnalyserParam=SystemBlackboard+[0x388]
PlayerParam=SystemBlackboard+[0x3A8]
PlayerCameraTargetParam=SystemBlackboard+[0x3B8]
PointLightParam=SystemBlackboard+[0x3C8]
RiderParam=SystemBlackboard+[0x410]
SensorHitParam=SystemBlackboard+[0x428]
ShooterParam=SystemBlackboard+[0x448]
SoundFootStepParam=SystemBlackboard+[0x468]
SoundOcclusionParam=SystemBlackboard+[0x470]
SpecialPowerParam=SystemBlackboard+[0x478]
SwordBlurParam=SystemBlackboard+[0x4A8]
TargetParam=SystemBlackboard+[0x4B0]
WorldInfoParam=SystemBlackboard+[0x518]

# Equip is an actor 228=Blackboard > 2F8=LifeParam / 228=WeaponParam / 480=SpecialPowerReceiverParam
Current_Weapon=EquipmentUserParam+[0x28,0x40]
Current_2=EquipmentUserParam+[0x40,0x40]
Current_3=EquipmentUserParam+[0x58,0x40]
Current_Bow=EquipmentUserParam+[0x70,0x40]
Current_Shield=EquipmentUserParam+[0x88,0x40]
Current_6=EquipmentUserParam+[0xA0,0x40]
Current_7=EquipmentUserParam+[0xB8,0x40]
Current_8=EquipmentUserParam+[0xD0,0x40]
Current_Head=EquipmentUserParam+[0xE8,0x40]
Current_Upper=EquipmentUserParam+[0x100,0x40]
Current_Lower=EquipmentUserParam+[0x118,0x40]
Current_Sheath=EquipmentUserParam+[0x130,0x40]
Current_13=EquipmentUserParam+[0x148,0x40]
Current_14=EquipmentUserParam+[0x160,0x40]
Current_Quiver=EquipmentUserParam+[0x178,0x40]
Current_ArmorExtra1=EquipmentUserParam+[0x190,0x40]
Current_ArmorExtra2=EquipmentUserParam+[0x1A8,0x40]
Current_SupportDevice=EquipmentUserParam+[0x1C0,0x40]
Current_PlayerRaulHand=EquipmentUserParam+[0x1D8,0x40]
Current_Accessory_Battery=EquipmentUserParam+[0x1F0,0x40]
Current_Player=EquipmentUserParam+[0x1F0,0x40]

EquipmentName=[0x218]
RemainingDurability=[0x220 if GetBID()=='082CE09B06E33A12' else 0x228,0x2F8,0x1830,0x8]
MaxDurability=[0x220 if GetBID()=='082CE09B06E33A12' else 0x228,0x2F8,0x1838,0x8]

CurrentWeapon_RemainingDurability = Current_Weapon + RemainingDurability
CurrentBow_RemainingDurability = Current_Bow + RemainingDurability
CurrentShield_RemainingDurability = Current_Shield + RemainingDurability

CurrentWeapon_MaxDurability = Current_Weapon + MaxDurability
CurrentBow_MaxDurability = Current_Bow + MaxDurability
CurrentShield_MaxDurability = Current_Shield + MaxDurability

CurrentWeapon_Name = Current_Weapon + EquipmentName
CurrentBow_Name = Current_Bow + EquipmentName
CurrentShield_Name = Current_Shield + EquipmentName
Current_Head_Name = Current_Head + EquipmentName
Current_Upper_Name = Current_Upper + EquipmentName
Current_Lower_Name = Current_Lower + EquipmentName
Current_Sheath_Name = Current_Sheath + EquipmentName
Current_Quiver_Name = Current_Quiver + EquipmentName
Current_ArmorExtra1_Name = Current_ArmorExtra1 + EquipmentName
Current_ArmorExtra2_Name = Current_ArmorExtra2 + EquipmentName


ASOptimize = SystemBlackboard+[0x40]
MovementForce = ASOptimize + [0x98]

Storage=[StorageAOB]
# Storage=[0x47242B8]

Quest = Storage+[0x60*20+0x18] # total 0x6D5

Currency = Storage+[0x60*2+0x18] # total 0x162A
Rupee = Currency+[0xA3A*0x40+0x24]

FloatVar = Storage+[0x60*4+0x18] # total 0x38
# CurrBattery = FloatVar+ [0x1F*0x28+0x1C]
MaxBattery = FloatVar+ [0x23*0x28+0x1C]
MaxSP = FloatVar+ [0x24*0x28+0x1C]

Location = Storage+[0x60*0xB+0x18] # total 0xC
RedMark = Location+[0x48*9+0x30,0]
CustomMark = Location+[0x48*10+0x30,0]

IntegerVars=Storage+[0x60*3+0x18] # total 0x24C
Arrows=IntegerVars+[0x2F*0x40+0x28,0] # total 2
BowBonusPower = IntegerVars+[0x31*0x40+0x28,0] # total 0x1C
BowDurability = IntegerVars+[0x32*0x40+0x28,0] # total 0x1C
BowPouch = IntegerVars+[0x34*0x40+0x28,0] # total 2
MealQuantity=IntegerVars+[0x39*0x40+0x28,0] # total 120
MealBonusLevel=IntegerVars+[0x35*0x40+0x28,0] # total 120
MealBonusTime=IntegerVars+[0x36*0x40+0x28,0] # total 120
MealBonusHeart=IntegerVars+[0x37*0x40+0x28,0] # total 120
Keyitem = IntegerVars+[0x3A*0x40+0x28,0] # total 200
Material=IntegerVars+[0x3C*0x40+0x28,0] # total 510
ShieldBonusPower = IntegerVars+[0x41*0x40+0x28,0] # total 0x28
ShieldDurability = IntegerVars+[0x43*0x40+0x28,0] # total 0x28
ShieldPouch = IntegerVars+[0x45*0x40+0x28,0] # total 2
ZonaiDevices = IntegerVars+[0x46*0x40+0x28,0] # total 0x3C (60)
WeaponMagicPower = IntegerVars+[0x4A*0x40+0x28,0] # total 0x28
WeaponBonusPower = IntegerVars+[0x4C*0x40+0x28,0] # total 0x28
WeaponDurability = IntegerVars+[0x4E*0x40+0x28,0] # total 0x28
WeaponPouch = IntegerVars+[0x51*0x40+0x28,0] # total 

HashVars=Storage+[0x60*7+0x18] # total 0x10F
BowEffect=HashVars+[0x13*0x50+0x28,0] # total 28
MealEffect=HashVars+[0x14*0x50+0x28,0] # total 120
ShieldEffect=HashVars+[0x15*0x50+0x28,0] # total 40
WeaponEffect=HashVars+[0x16*0x50+0x28,0] # total 40

Horses=Storage+[0x60*0x8+0x18] # 0x9 total

ItemIDs=Storage+[0x60*0x11+0x18] # 0x119 total
ArrowsSlots = ItemIDs+[0xB*0x90+0x78,0] # NormalArrow
BowSlots = ItemIDs+[0xC*0x90+0x78,0] # total 28 , e.g. Weapon_Bow_101, Weapon_Bow_072, Weapon_Bow_036
WeaponSlots = ItemIDs+[0x16*0x90+0x78,0] # total 40
WeaponLinkedObjectSlots = ItemIDs+[0x15*0x90+0x78,0] # total 40  e.g. FldObj_PushRock_A_M_01  Item_Enemy_225
WeaponLinkedObjectSlot2 = ItemIDs+[0x15*0x90+0x78,0x50] 
ShieldSlots = ItemIDs+[0x12*0x90+0x78,0] #total 40
ShieldLinkedObjectSlots = ItemIDs+[0x11*0x90+0x78,0] #  SpObj_FlameThrower_A_01 
ArmorSlots = ItemIDs+[0x9*0x90+0x78,0] # Armor_1050_Lower, Armor_1055_Lower, Armor_1060_Lower, Armor_1065_Lower, Armor_1075_Lower
ZonaiDevicesSlots = ItemIDs+[0x13*0x90+0x78,0] # #total 60 SpObj_CookSet_Capsule_A_01 / SpObj_FlameThrower_Capsule_A_01 / SpObj_WindGenerator_Capsule_A_01 / SpObj_LiftGeneratorWing_Capsule_A_01 / SpObj_ControlStick_Capsule_A_01 / SpObj_FloatingStone_Capsule_A_01
AbilityObjSlots = ItemIDs+[0x14*0x90+0x78,0] # #total 20 Obj_UltraHand / Obj_OneTouchBond / Obj_Tooreroof / Obj_ReverseRecorder
CollectionHistory = ItemIDs+[0xD*0x90+0x78,0] # 600
CookHistory = ItemIDs+[0xE*0x90+0x78,0] # total 120
KeySlots = ItemIDs+[0xF*0x90+0x78,0] # total 200  Obj_DRStone_Get / Obj_Battery_Get / Obj_DungeonClearSeal / Obj_KorokNuts / CaveMasterMedal / Parasail / Obj_Camera / MinusRupee_00 / Energy_Material_01
MaterialSlots = ItemIDs+[0x10*0x90+0x78,0] # total 510

WalkSpeed=ConditionParam+[0x20,0x1C8]
SwimSpeed=ConditionParam+[0x20,0x1E0]
SwimDash=ConditionParam+[0x20,0x1F0]
ClimbSpeed=ConditionParam+[0x20,0x208]
AttackUp=ConditionParam+[0x20,0x248]
DefenseUp=ConditionParam+[0x20,0x280]
SlipResistance=ConditionParam+[0x20,0x220]
SlipResistance2=ConditionParam+[0x20,0x230]
StealthUp=ConditionParam+[0x20,0x290]
RupeePadding=ConditionParam+[0x20,0x2B0]
Skydive=ConditionParam+[0x20,0x2C0]
EnergyUp=ConditionParam+[0x20,0x2D0]



HeartsMax = 40;
StaminaMax = 3000;
RupeesMax = 999999;
ArrowsMax = 999;
BatteryMax = 48000;
GameplayTimeMax = 10000 * 60 * 60 - 1;
WeaponMax = 20;
WeaponBonusPowerMax = 1000;
WeaponDurabilityMax = 1000;
BowMax = 14;
BowBonusPowerMax = 1000;
BowDurabilityMax = 1000;
ShieldMax = 20;
ShieldBonusPowerMax = 1000;
ShieldDurabilityMax = 1000;
ArmorMax = 150;
MaterialMax = 255;
MaterialQuantityMax = 999;
MealMax = 60;
MealQuantityMax = 999;
MealBonusHeartMax = 99;
MealBonusLevelMax = 999;
MealBonusTimeMax = 5940;
MealUnknownMax = 9999;
ZonaiDeviceMax = 30;
ZonaiDeviceQuantityMax = 999;
KeyItemMax = 100;
KeyItemQuantityMax = 9999;
MaxPonyPoints = 9999;


Jump=[JumpAOB,0xC8,0x178,0x30,0xFC]
# Jump = [0x47203D0]+[0xC8,0x178,0x30,0xFC] 

Scene=[SceneAOB]
# Scene = [0x472AC58]
Battery = Scene+[0x1E8,0x58,0xF8,0x5C]



def MarkClass(Classes):
    for classname in Classes:
        addr=ptr(eval(classname),returnResult=True)
        if notFound(addr): 
            print('Error with %s'%classname)
            continue
        MarkOffset(addr)
        classAddr=GetQword(addr)
        ApplyStruct(classAddr,'class')
        Patch(classAddr,classname)

def MarkValue(varnames):
    for varname in varnames:
        addr=ptr(eval(varname),returnResult=True)
        if notFound(addr): 
            print('Error with %s'%varname)
            continue
        # MarkOffset(addr) Todo: handle type
        Patch(addr,varname)

if isGDB():
    MarkClass(['Player','Physics',
        'GameParameterTable','LODParam','Logic','ActorPositionCalculatorParam','AffiliationParam', 'AttentionReceiverParam', 'BSAParam', 'BuffParam', 'ChemicalParam', 'ConditionParam', 'DeathParam', 'Blur', 'EquipmentUserParam', 'EventColorVariationParam', 'GameBalanceClientParam', 'LifeParam', 'LifterParam', 'PathFindingParam', 'PerceptionEmitterParam', 'PerimeterAnalyserParam', 'PlayerParam', 'PlayerCameraTargetParam', 'PointLightParam', 'RiderParam', 'SensorHitParam', 'ShooterParam', 'SoundFootStepParam', 'SoundOcclusionParam', 'SpecialPowerParam', 'SwordBlurParam', 'TargetParam', 'WorldInfoParam',
        'Storage', 'IntegerVars', 'ItemIDs', 'Current_Weapon', 'Current_2', 'Current_3', 'Current_Bow', 'Current_Shield', 'Current_6', 'Current_7', 'Current_8', 'Current_Head', 'Current_Upper', 'Current_Lower', 'Current_Sheath', 'Current_13', 'Current_14', 'Current_Quiver', 'Current_ArmorExtra1', 'Current_ArmorExtra2', 'Current_SupportDevice', 'Current_PlayerRaulHand', 'Current_Accessory_Battery','Location'])

    MarkValue([
        'SystemBlackboard', 'HP', 'MaxHP', 'Damage', 'SP', 'ASOptimize', 'MovementForce', 'FloatVar', 'MaxBattery',
        'Storage', 'Rupee', 'Arrows', 'Material', 'MealQuantity', 'MealBonusLevel', 'MealBonusTime', 'MealBonusHeart', 'Keyitem', 'ZonaiDevices', 'WeaponPouch', 'BowPouch', 'ShieldPouch',
        'ArrowsSlots', 'BowSlots', 'WeaponSlots', 'WeaponLinkedObjectSlots', 'WeaponLinkedObjectSlot2', 'ShieldSlots', 'ShieldLinkedObjectSlots', 'ArmorSlots', 'AbilityObjSlots', 'ZonaiDevicesSlots', 'CollectionHistory', 'CookHistory', 'KeySlots', 'MaterialSlots', 
        'WalkSpeed', 'SwimSpeed', 'SwimDash', 'ClimbSpeed', 'AttackUp', 'DefenseUp', 'SlipResistance', 'SlipResistance2', 'StealthUp', 'RupeePadding', 'Skydive', 'EnergyUp',
        'Jump', 'Battery', 'Current_Player', 'CurrentWeapon_RemainingDurability', 'CurrentBow_RemainingDurability', 'CurrentShield_RemainingDurability', 'CurrentWeapon_MaxDurability', 'CurrentBow_MaxDurability', 'CurrentShield_MaxDurability', 'CurrentWeapon_Name', 'CurrentBow_Name', 'CurrentShield_Name', 'Current_Head_Name', 'Current_Upper_Name', 'Current_Lower_Name', 'Current_Sheath_Name', 'Current_Quiver_Name', 'Current_ArmorExtra1_Name', 'Current_ArmorExtra2_Name','RedMark','CustomMark'
        ])



################################ START ######################################
Init('The Legend of Zelda, Tears of the Kingdom' , '薩爾達傳說 王國之淚')
# Game Name in English, and then secondary Language

AddCheat('Max Heart %d (use after the 4th temple)'%HeartsMax, '生命上限 %d (警告,第四神廟之後才可使用)'%HeartsMax,1)
# CodeCave('17 09 40 B9 68 22 4C F9',['MOV W23, #160', 'STR W23, [X8,#8]','RET'])
PointerHack(MaxHP,HeartsMax*4)

AddCheat('Max Heart 3 (Use in Temple of Time)', '生命上限 3 (最初空島時之廟中門試力用)',2)
# CodeCave('17 09 40 B9 68 22 4C F9',['MOV W23, #160', 'STR W23, [X8,#8]','RET'])
PointerHack(MaxHP,12)

AddCheat('Max Stamina (3 rings)', '耐力上限 Max')
# CodeCave('00 1D 40 BD E0 03 00 BD E0 03 40 BD',['LDR S0, {end}-4', 'STR S0, [X8,#0x1C]','RET',Float2DWord(3000)],False)
PointerHack(MaxSP,Float2DWord(StaminaMax))

AddCheat('Heart always full (No Miasma)', '生命常滿 (瘴氣不浸)')
# CodeCave('08 09 40 B9 F3 53 40 F9',['LDR X9, [X24,#0x1838]', 'LDR W9, [X9,#8]', 'STR W9, [X8,#8]', 'MOV W8, W9', 'RET'])
PointerCopyValue(HP,MaxHP)
InsertCheatCode(4,PointerCodeCopyRegister('B','F'))
AddCheatCode(PointerCodeAddOffset(Miasma[-2],'B')+PointerCodeAddRegister(Miasma[-1],'B')+PointerCodeWrite(4,0,register='B',use_D=False))

AddCheat('Stamina always full', '耐力常滿')
# Hack('68 00 00 54 08 1C A0 4E','FMOV S1, S0')
PointerCopyValue(SP,MaxSP)

AddCheat('Weapon Durability Max', '武器耐久 Max',1)
PointerCopyValue(CurrentWeapon_RemainingDurability,CurrentWeapon_MaxDurability)

AddCheat('Weapon Durability Keep 2', '武器耐久 保持2',2)
PointerHack(CurrentWeapon_RemainingDurability,2)

AddCheat('Current Weapon Durability 99999', '武器耐久 99999',2)
PointerHack(CurrentWeapon_RemainingDurability,99999)

AddCheat('Bow Durability Max', '弓耐久 Max')
PointerCopyValue(CurrentBow_RemainingDurability,CurrentBow_MaxDurability)

AddCheat('Shield Durability Max', '盾耐久 Max')
PointerCopyValue(CurrentShield_RemainingDurability,CurrentShield_MaxDurability)

AddCheat('%d Arrows'%(ArrowsMax-111), '%d 木箭'%(ArrowsMax-111))
PointerHack(Arrows,ArrowsMax-111)

AddCheat('Rupee %d'%(RupeesMax-1), '盧比 %d'%(RupeesMax-1))
PointerHack(Rupee,RupeesMax-1)

AddCheat('Max Pouch for Bow %d'%BowMax, '弓 槽位最大 %d'%BowMax)
PointerHack(BowPouch,BowMax)

AddCheat('Max Pouch for Shield %d'%ShieldMax, '盾 槽位最大 %d'%ShieldMax)
PointerHack(ShieldPouch,ShieldMax)

AddCheat('Max Pouch for Weapon %d'%WeaponMax, '武器 槽位最大 %d'%WeaponMax)
PointerHack(WeaponPouch,WeaponMax)



AddCheat('All Material 888', '已收集材料 888')
PointerFillRange(Material, MaterialMax, 888, length=4, condition='!=', conditionValue=0xFFFFFFFF)

AddCheat('All Cooked Food 888', '烹調食物 888',1)
PointerFillRange(MealQuantity, MealMax, 888, length=4, condition='!=', conditionValue=0xFFFFFFFF)

AddCheat('All Cooked Food 1', '烹調食物 1',2)
PointerFillRange(MealQuantity, MealMax, 1, length=4, condition='!=', conditionValue=0xFFFFFFFF)

AddCheat('Key Item 888 (Dangerous)', '重要物品 888 (慎用)')
PointerFillRange(Keyitem, KeyItemMax, 888, length=4, condition='!=', conditionValue=0xFFFFFFFF)

AddCheat('Zonai Devices 888', '左納烏裝置 888')
PointerFillRange(ZonaiDevices, ZonaiDeviceMax, 888, length=4, condition='!=', conditionValue=0xFFFFFFFF)

AddCheat('Moon Jump (Hold ZL+X)', '奔月跳 (長按ZL+X)')
PointerHack(Jump,Float2DWord(10),useButton=['zl','x'])

AddCheat('Super Speed Up (Hold ZL+B)', '極限速度提升 (長按 ZL+B)')
PointerHack(MovementForce,Float2DWord(4),useButton=['ZL','B'],default=Float2DWord(1))

AddCheat('Speed Up Effect Boost', '增強移動速度提升效果')
PointerHack(WalkSpeed,[Float2DWord(1.5),Float2DWord(2.0),Float2DWord(2.5),Float2DWord(3)])

AddCheat('Swimming Effect Boost', '增強游泳速度提升效果')
PointerHack(SwimSpeed,[Float2DWord(1.5),Float2DWord(2.5),Float2DWord(3.5),Float2DWord(4.5)])
PointerHack(SwimDash,[Float2DWord(1.5),Float2DWord(2.0),Float2DWord(2.5),Float2DWord(3.0)])

AddCheat('Climbing Effect Boost', '增強攀爬速度提升效果')
PointerHack(ClimbSpeed,[Float2DWord(1.5),Float2DWord(2.5),Float2DWord(3.5),Float2DWord(4.5)])

AddCheat('Attack Up Effect Boost', '增強攻擊力提升效果')
PointerHack(AttackUp,[Float2DWord(1.5),Float2DWord(2.5),Float2DWord(3.5),Float2DWord(4.5)])

AddCheat('Defense Up Effect Boost', '增強防禦力提升效果')
PointerHack(DefenseUp,[Float2DWord(10),Float2DWord(20),Float2DWord(30),Float2DWord(50)])

AddCheat('Slip Resistance Effect Boost', '增強滑落減輕效果')
PointerHack(SlipResistance,[Float2DWord(150),Float2DWord(400),Float2DWord(700),Float2DWord(1000)])
PointerHack(SlipResistance2,[Float2DWord(0.75),Float2DWord(0.55),Float2DWord(0.3),Float2DWord(0.1)])

AddCheat('Skydive Mobility Up Effect Boost', '增強俯衝機動力效果')
PointerHack(Skydive,[Float2DWord(1.5),Float2DWord(2.5),Float2DWord(3.5),Float2DWord(4.5)])

AddCheat('Stealth Up Effect Boost', '增強寧靜隱身效果')
PointerHack(StealthUp,[Float2DWord(0.6),Float2DWord(0.4),Float2DWord(0.2),Float2DWord(0)])

AddCheat('Energy Up Effect Boost', '增強 能源持久 效果')
PointerHack(EnergyUp,[Float2DWord(0.5),Float2DWord(0.33),Float2DWord(0.2),Float2DWord(0.1)])

AddCheat('Inf. Battery', '無限能源')
PointerCopyValue(Battery,MaxBattery)

AddCheat('Max Battery Capacity', '能源容量上限 Max')
PointerHack(MaxBattery,Float2DWord(BatteryMax))

AddCheat('Travel Medallion Mark follows Red Mark', '傳送標記追隨紅色標記')
PointerCopyValue(CustomMark,RedMark,12)

AddCheat('Buff LV3 & 30min', '提升效果 LV3 & 30分鐘')
PointerHack(BuffParam+[0x158],Float2DWord(1800*30)+Value2DWord(3),8)

# effect=(None,'Heat Resistance', 'Flame Guard', 'Cold Resistance', 'Shock Resistance', 
    # 'Lightning Proof', 'UnFreezable', None, 'Swim Speed Up', 'Swim Dash Stamina Up', 
    # None, None, 'Climb Speed Up', None, 'Attack Up', 
    # 'Cold Weather Attack', 'Hot Weather Attack', 'Stormy Weather Attack', None, None,
    # 'Stealth Up', 'Sand Speed Up', 'Snow Speed Up', None, None, 
    # None, 'Defense Up', 'Speed Up', 'Gloom Resistance', None,
     # None, None, None, None, 'Disguise; Bone Weap. Porf.', 
     # None, 'Extra Heart', 'Stamina Recovery', 'Extra Stamina', 'Gloom Recovery',
     # 'Skydive Mobility Up', 'Slip Resistance', None, 'Glow', 'Rupee Padding', 
     # None, 'Master Sword Beam Up', None, 'Night Speed Up', None,
     # 'Climbing Jump Stamina Up', 'Charge Atk. Stamina Up', None, 'Fireproof', 'Impact Proof', 
     # 'Slip Proof', None, None, 'Energy Up', 'Energy Recharge Up',
     # None, 'Gloom Attack Resist', 'Cold Weather Charge', 'Hot Weather Charge', 
     # 'Stormy Weather Charge', 'Shining Steps')
# effectC=(None, '耐熱防護', '耐火防護', '耐寒防護', '電麻防護', '雷電無效', '凍結無效', None, '游泳速度提升', '加速游泳精力持久', 
    # None, None, '攀登速度提升', None, '攻擊力提升', '低溫時冷氣攻擊', '高溫時火焰攻擊', '雷雨時電流攻擊', None, None, 
    # '安靜度提升', '沙上速度提升', '雪上速度提升', None, None, None, '防禦提升', '移動力提升', '瘴氣防護', None,
    # None, None, None, None, '骸骨變裝 擅長骨武器', None, 'MAX心心', '恢復精力', 'MAX精力', '瘴氣傷害恢復', 
    # '俯衝機動力提升', '滑落減輕', None, '發光', '傷害盧比交換', None, '大師之劍劍氣強化', None, '夜間移動速度提升', None, 
    # '攀登跳躍精力持久', '蓄力攻擊精力持久', None, '火焰無效', '落下傷害無效', '滑落無效', None, None, '能源持久', '能源恢復速度提升',
    # None, '瘴氣防護提升', '低溫時蓄力攻擊強化', '高溫時蓄力攻擊強化', '雷雨時蓄力攻擊強化', '光之足跡')
# for i in range(len(effect)):
    # if effect[i] == None: continue
    # AddCheat('Buff %d - %s'%(i,effect[i]), '效果 %d - %s'%(i,effectC[i]),1 if i==1 else 2, showOption=None)
    # PointerHack(BuffParam+[0x154],i)


def validBit(bit): return 256**bit-1 if bit>=0 else 0
def AppendItem(itemPointer, arraySize, fieldLength, itemName, quantityPointer=None, value=None, useButton=None):
    codes = PointerCodeHeader(itemPointer[:-1],'F')
    codes += PointerCodeCopyRegister('5','F')
    codes += PointerCodeAddOffset(itemPointer[-1],'F')
    codes += PointerCodeAddOffset(itemPointer[-1],'5')
    codes += PointerCodeArithmetic('-','5','5','F')
    codes += PointerCodeSetValue(0xFFFFFFFFFFFFFFFF,'E') # E = item index (in decending order)
    codes += PointerCodeAddRegister(fieldLength*arraySize,'F') # F = working address
    # codes += PointerCodeSetValue(0x30,'7') #debug

    # loop for checking whether the item exist, it also record the address of first available item space 
    codes += PointerCodeStartLoop(arraySize)
    codes += PointerCodeArithmetic('-','F','F',fieldLength)
    # codes += PointerCodeStoreRegisterValueToRegisterAddress('C','F',8,'7')  #debug
    
    # Check whether the slot is empty
    codes += PointerCodeCopyRegister('A','F') 
    codes += PointerCodeReadOffset(0,'A',8)
    codes += PointerCodeArithmetic('and','B','A',0xFF)
    codes += PointerCodeCondition('B','==',0,1) 

    # if yes
    codes += PointerCodeArithmetic('*','D','C',4) # calculate the quantity offset by current loop index
    codes += PointerCodeCopyRegister('E','F')  # mark the new item address to here

    # else
    codes += PointerCodeElseBlock()

    # get the current item name
    codes += PointerCodeCopyRegister('B','F') 
    codes += PointerCodeReadOffset(8,'B',8)
    if len(itemName)<16: 
        codes += PointerCodeArithmetic('and','B','B',validBit(len(itemName)-8))
    elif len(itemName)<24: 
        codes += PointerCodeCopyRegister('8','F') 
        codes += PointerCodeReadOffset(16,'8',8)
        codes += PointerCodeArithmetic('and','8','8',validBit(len(itemName)-16))
    elif len(itemName)<32: 
        codes += PointerCodeCopyRegister('8','F') 
        codes += PointerCodeReadOffset(16,'8',8)
        codes += PointerCodeCopyRegister('7','F') 
        codes += PointerCodeReadOffset(24,'7',8)
        codes += PointerCodeArithmetic('and','7','7',validBit(len(itemName)-24))
    else: 
        codes += PointerCodeCopyRegister('8','F') 
        codes += PointerCodeReadOffset(16,'8',8)
        codes += PointerCodeCopyRegister('7','F') 
        codes += PointerCodeReadOffset(24,'7',8)
        codes += PointerCodeCopyRegister('6','F') 
        codes += PointerCodeReadOffset(32,'6',8)
        codes += PointerCodeArithmetic('and','6','6',validBit(len(itemName)-32))

    # check whether current item has the same name as new item
    codes += PointerCodeCondition('A','==',Char2QwordList((itemName+chr(0)*16)[:8])[0],8)
    codes += PointerCodeCondition('B','==',Char2QwordList((itemName+chr(0)*16)[8:16])[0],8)
    if len(itemName)>=16: codes += PointerCodeCondition('8','==',Char2QwordList((itemName+chr(0)*16)[16:24])[0],8)
    if len(itemName)>=24: codes += PointerCodeCondition('7','==',Char2QwordList((itemName+chr(0)*16)[24:32])[0],8)
    if len(itemName)>=32: codes += PointerCodeCondition('6','==',Char2QwordList((itemName+chr(0)*16)[32:40])[0],8)

    # if so, Mark new item index to False and exit the loop immediately
    codes += PointerCodeSetValue(0xFFFFFFFFFFFFFFFF,'E')
    codes += PointerCodeSetValue(1,'C') # quit the loop
    # codes += PointerCodeWrite(8,0x102030405060708,None,'F','7')  #debug
    
    codes += PointerCodeEndBlock()
    codes += PointerCodeEndBlock()
    if len(itemName)>=16: codes += PointerCodeEndBlock()
    if len(itemName)>=24: codes += PointerCodeEndBlock()
    if len(itemName)>=32: codes += PointerCodeEndBlock()

    codes += PointerCodeEndBlock()

    codes += PointerCodeEndLoop()

    # only do the action when the item does not exist and there is empty slot
    codes += PointerCodeCondition('E','!=',0xFFFFFFFFFFFFFFFF,8)
    
    # mark the name to the first empty slot
    codes += PointerCodeArithmetic('+','5','5','E')
    codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[:8])[0],register='E',use_D=False,increase=True)
    codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[8:16])[0],register='E',use_D=False,increase=True)
    if len(itemName)>=16: codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[16:24])[0],register='E',use_D=False,increase=True)
    if len(itemName)>=24: codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[24:32])[0],register='E',use_D=False,increase=True)
    if len(itemName)>=32: codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[32:40])[0],register='E',use_D=False,increase=True)
    codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[:8])[0],register='5',use_D=False,increase=True)
    codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[8:16])[0],register='5',use_D=False,increase=True)
    if len(itemName)>=16: codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[16:24])[0],register='5',use_D=False,increase=True)
    if len(itemName)>=24: codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[24:32])[0],register='5',use_D=False,increase=True)
    if len(itemName)>=32: codes += PointerCodeWrite(8,Char2QwordList((itemName+chr(0)*16)[32:40])[0],register='5',use_D=False,increase=True)
    
    # set the quantity
    if (quantityPointer!=None):
        codes += PointerCodeArithmetic('-','D','D',4)
        codes += PointerCodeHeader(quantityPointer[:-1],'F')
        if quantityPointer[-1]!=0: codes += PointerCodeAddRegister(quantityPointer[-1],'F')
        codes += PointerCodeWrite(4,value,register='F',use_D='D',increase=False)

    codes += PointerCodeEndBlock()
    
    if useButton != None: codes= ButtonCode(useButton,codes)
    AddCheatCode(codes)

def RemoveItem(itemPointer, arraySize, fieldLength, itemName, quantityPointer=None):
    codes = PointerCodeHeader(itemPointer[:-1],'F')
    codes += PointerCodeCopyRegister('5','F')
    codes += PointerCodeAddOffset(itemPointer[-1],'F')
    codes += PointerCodeAddOffset(itemPointer[-1],'5')
    codes += PointerCodeArithmetic('-','5','5','F')
    codes += PointerCodeSetValue(0xFFFFFFFFFFFFFFFF,'E') # E = item index (in decending order)
    codes += PointerCodeAddRegister(fieldLength*arraySize,'F') # F = working address

    # loop for checking whether the item exist, it also record the address of first available item space 
    codes += PointerCodeStartLoop(arraySize)
    codes += PointerCodeArithmetic('-','F','F',fieldLength)
    
    # Check whether the slot is empty
    codes += PointerCodeCopyRegister('A','F') 
    codes += PointerCodeReadOffset(0,'A',8)
    # codes += PointerCodeArithmetic('and','B','A',0xFF)
    # codes += PointerCodeCondition('B','==',0,1) 

    # if yes
    # codes += PointerCodeArithmetic('*','D','C',4) # calculate the quantity offset by current loop index
    # codes += PointerCodeCopyRegister('E','F')  # mark the new item address to here

    # else
    # codes += PointerCodeElseBlock()

    # get the current item name
    codes += PointerCodeCopyRegister('B','F') 
    codes += PointerCodeReadOffset(8,'B',8)
    if len(itemName)<16: 
        codes += PointerCodeArithmetic('and','B','B',validBit(len(itemName)-8))
    elif len(itemName)<24: 
        codes += PointerCodeCopyRegister('8','F') 
        codes += PointerCodeReadOffset(16,'8',8)
        codes += PointerCodeArithmetic('and','8','8',validBit(len(itemName)-16))
    elif len(itemName)<32: 
        codes += PointerCodeCopyRegister('8','F') 
        codes += PointerCodeReadOffset(16,'8',8)
        codes += PointerCodeCopyRegister('7','F') 
        codes += PointerCodeReadOffset(24,'7',8)
        codes += PointerCodeArithmetic('and','7','7',validBit(len(itemName)-24))
    else: 
        codes += PointerCodeCopyRegister('8','F') 
        codes += PointerCodeReadOffset(16,'8',8)
        codes += PointerCodeCopyRegister('7','F') 
        codes += PointerCodeReadOffset(24,'7',8)
        codes += PointerCodeCopyRegister('6','F') 
        codes += PointerCodeReadOffset(32,'6',8)
        codes += PointerCodeArithmetic('and','6','6',validBit(len(itemName)-32))

    # check whether current item has the same name as new item
    codes += PointerCodeCondition('A','==',Char2QwordList((itemName+chr(0)*16)[:8])[0],8)
    codes += PointerCodeCondition('B','==',Char2QwordList((itemName+chr(0)*16)[8:16])[0],8)
    if len(itemName)>=16: codes += PointerCodeCondition('8','==',Char2QwordList((itemName+chr(0)*16)[16:24])[0],8)
    if len(itemName)>=24: codes += PointerCodeCondition('7','==',Char2QwordList((itemName+chr(0)*16)[24:32])[0],8)
    if len(itemName)>=32: codes += PointerCodeCondition('6','==',Char2QwordList((itemName+chr(0)*16)[32:40])[0],8)

    # if so, Mark new item index as current position and exit the loop immediately
    codes += PointerCodeCopyRegister('E','F')  # mark the item address to here
    codes += PointerCodeSetValue(1,'C') # quit the loop
    
    codes += PointerCodeEndBlock()
    codes += PointerCodeEndBlock()
    if len(itemName)>=16: codes += PointerCodeEndBlock()
    if len(itemName)>=24: codes += PointerCodeEndBlock()
    if len(itemName)>=32: codes += PointerCodeEndBlock()

    # codes += PointerCodeEndBlock()

    codes += PointerCodeEndLoop()

    # only do the action when the item does not exist and there is empty slot
    codes += PointerCodeCondition('E','!=',0xFFFFFFFFFFFFFFFF,8)
    
    # mark the name to the first empty slot
    codes += PointerCodeArithmetic('+','5','5','E')
    codes += PointerCodeWrite(1,0,register='E',use_D=False,increase=False)
    codes += PointerCodeWrite(1,0,register='5',use_D=False,increase=True)
    
    # set the quantity
    if (quantityPointer!=None):
        codes += PointerCodeArithmetic('-','D','D',4)
        codes += PointerCodeHeader(quantityPointer[:-1],'F')
        if quantityPointer[-1]!=0: codes += PointerCodeAddRegister(quantityPointer[-1],'F')
        codes += PointerCodeWrite(4,0xFFFFFFFF,register='F',use_D='D',increase=False)

    codes += PointerCodeEndBlock()
    
    AddCheatCode(codes)



AddCheat('Add Fairy', '添加 妖精')
AppendItem(MaterialSlots, MaterialMax, 0x50, 'Animal_Insect_F', Material, 999)
AddCheat('Remove Fairy', '移除 妖精')
RemoveItem(MaterialSlots, MaterialMax, 0x50, 'Animal_Insect_F', Material)

AddCheat('Add Golden Apple', '添加 金蘋果')
AppendItem(MaterialSlots, MaterialMax, 0x50, 'Item_Fruit_P', Material, 999)
AddCheat('Remove Golden Apple', '移除 金蘋果')
RemoveItem(MaterialSlots, MaterialMax, 0x50, 'Item_Fruit_P', Material)

AddCheat('Add Big Hearty Radish', '添加 生命大蘿蔔')
AppendItem(MaterialSlots, MaterialMax, 0x50, 'Item_PlantGet_C', Material, 999)
AddCheat('Remove Big Hearty Radish', '移除 生命大蘿蔔')
RemoveItem(MaterialSlots, MaterialMax, 0x50, 'Item_PlantGet_C', Material)

AddCheat('Add Silver Lynel Saber Horn', '添加 白銀萊尼爾的刄角')
AppendItem(MaterialSlots, MaterialMax, 0x50, 'Item_Enemy_151', Material, 999)
AddCheat('Remove Silver Lynel Saber Horn', '移除 白銀萊尼爾的刄角')
RemoveItem(MaterialSlots, MaterialMax, 0x50, 'Item_Enemy_151', Material)

AddCheat('Add Ancient Blade', '添加 古代之刄')
AppendItem(MaterialSlots, MaterialMax, 0x50, 'Item_Weapon_01', Material, 999)
AddCheat('Remove Ancient Blade', '移除 古代之刄')
RemoveItem(MaterialSlots, MaterialMax, 0x50, 'Item_Weapon_01', Material)

AddCheat('Add Master Sword to Weapon Slot', '添加 大師之劍')
AppendItem(WeaponSlots, WeaponMax, 0x50, 'Weapon_Sword_070')
# AddCheat('Add Original Master Sword to Weapon Slot', '添加 初始大師之劍')
# AppendItem(WeaponSlots, WeaponMax, 0x50, 'Weapon_Sword_077')
AddCheat('Add Gloom Sword to Weapon Slot', '添加 瘴氣之劍')
AppendItem(WeaponSlots, WeaponMax, 0x50, 'Weapon_Sword_166')
AddCheat('Add Gloom Club to Weapon Slot', '添加 瘴氣金屬棒')
AppendItem(WeaponSlots, WeaponMax, 0x50, 'Weapon_Lsword_166')
AddCheat('Add Gloom Spear to Weapon Slot', '添加 瘴氣之槍')
AppendItem(WeaponSlots, WeaponMax, 0x50, 'Weapon_Spear_166')

# AddCheat('Attach Weapon Slot 2 with Sapphire', '第二槽位武器附上藍寶石(冰效果)')
# PointerHack(WeaponLinkedObjectSlot2+[0], Char2QwordList(('Item_Ore_C'+chr(0)*40)[:16]), length=8)
# AddCheat('Attach Weapon Slot 2 with Ruby', '第二槽位武器附上紅寶石(火效果)')
# PointerHack(WeaponLinkedObjectSlot2+[0], Char2QwordList(('Item_Ore_B'+chr(0)*40)[:16]), length=8)
# AddCheat('Attach Weapon Slot 2 with Topaz', '第二槽位武器附上黃玉石(電效果)')
# PointerHack(WeaponLinkedObjectSlot2+[0], Char2QwordList(('Item_Ore_D'+chr(0)*40)[:16]), length=8)
# AddCheat('Attach Weapon Slot 2 with Opal', '第二槽位武器附上蛋白石(水效果)')
# PointerHack(WeaponLinkedObjectSlot2+[0], Char2QwordList(('Item_Ore_E'+chr(0)*40)[:16]), length=8)

AddCheat('Add Hylian Shield', '添加 海拉魯之盾')
AppendItem(ShieldSlots, ShieldMax, 0x50, 'Weapon_Shield_030')
# AddCheat('Add Royal Guard\'s Shield', '添加 近衞之盾')
# AppendItem(ShieldSlots, ShieldMax, 0x50, 'Weapon_Shield_033')
# AddCheat('Add Sea-Breeze Shield', '添加 海風盾')
# AppendItem(ShieldSlots, ShieldMax, 0x50, 'Weapon_Shield_057')

AddCheat('Add Demon King\'s Bow', '添加 魔王之弓')
AppendItem(BowSlots, BowMax, 0x50, 'Weapon_Bow_166')
AddCheat('Add Dusk Bow', '添加 黃昏之弓')
AppendItem(BowSlots, BowMax, 0x50, 'Weapon_Bow_072')
AddCheat('Add Steel Lizal Bow', '添加 鋼鐵蜥蜴弓 ')
AppendItem(BowSlots, BowMax, 0x50, 'Weapon_Bow_030')
AddCheat('Add Savage Lynel Bow', '添加 獸神弓')
AppendItem(BowSlots, BowMax, 0x50, 'Weapon_Bow_032')

AddCheat('Add Travel Medallion', '添加 傳送標記器')
AppendItem(KeySlots, KeyItemMax, 0x50, 'Obj_WarpDLC', Keyitem, 3)
AddCheat('Remove Travel Medallion', '移除 傳送標記器')
RemoveItem(KeySlots, KeyItemMax, 0x50, 'Obj_WarpDLC', Keyitem)

# AddCheat('Add Solemn Vow of Tulin, Sage of Wind', '添加 風之盟約')
# AppendItem(KeySlots, KeyItemMax, 0x50, 'Obj_SageSoulPlus_Rito')

AddCheat('Add Steering Stick', '添加 操縱桿')
AppendItem(ZonaiDevicesSlots, ZonaiDeviceMax, 0x50, 'SpObj_ControlStick_Capsule_A_01', ZonaiDevices, ZonaiDeviceQuantityMax)
AddCheat('Remove Steering Stick', '移除 操縱桿')
RemoveItem(ZonaiDevicesSlots, ZonaiDeviceMax, 0x50, 'SpObj_ControlStick_Capsule_A_01', ZonaiDevices)

AddCheat('Add Floating Stone', '添加 浮游石')
AppendItem(ZonaiDevicesSlots, ZonaiDeviceMax, 0x50, 'SpObj_FloatingStone_Capsule_A_01', ZonaiDevices, ZonaiDeviceQuantityMax)
AddCheat('Remove Floating Stone', '移除 浮游石')
RemoveItem(ZonaiDevicesSlots, ZonaiDeviceMax, 0x50, 'SpObj_FloatingStone_Capsule_A_01', ZonaiDevices)


armors=[
    'Armor_1040_Head',
    'Armor_1110_Upper',
    'Armor_1095_Head','Armor_1095_Upper','Armor_1095_Lower', 
    'Armor_061_Head','Armor_061_Upper','Armor_061_Lower', 
    'Armor_098_Head','Armor_098_Upper','Armor_098_Lower', 
    'Armor_151_Upper',
    'Armor_120_Head',
    'Armor_140_Head',
    'Armor_1149_Head','Armor_1149_Upper','Armor_1149_Lower', 
    'Armor_1050_Head','Armor_1050_Upper','Armor_1050_Lower', 
    'Armor_1055_Head','Armor_1055_Upper','Armor_1055_Lower', 
    'Armor_1070_Head','Armor_1070_Upper','Armor_1070_Lower', 
    'Armor_1145_Head','Armor_1145_Upper','Armor_1145_Lower', 
    'Armor_064_Head','Armor_064_Upper','Armor_064_Lower', 
    'Armor_067_Head','Armor_067_Upper','Armor_067_Lower', 
    'Armor_073_Head','Armor_073_Upper','Armor_073_Lower', 
    'Armor_076_Head','Armor_076_Upper','Armor_076_Lower', 
    'Armor_086_Head','Armor_086_Upper','Armor_086_Lower', 
    'Armor_106_Head','Armor_106_Upper','Armor_106_Lower', 
    'Armor_114_Head','Armor_114_Upper','Armor_114_Lower', 
    'Armor_229_Head','Armor_229_Upper','Armor_229_Lower',
    'Armor_090_Head','Armor_090_Upper','Armor_090_Lower', 
    'Armor_204_Head','Armor_204_Upper','Armor_204_Lower',
    'Armor_209_Head','Armor_209_Upper','Armor_209_Lower',
    'Armor_219_Head','Armor_219_Upper','Armor_219_Lower',
    'Armor_214_Head','Armor_214_Upper','Armor_214_Lower',
    'Armor_234_Head','Armor_234_Upper','Armor_234_Lower',
    'Armor_1100_Head','Armor_1100_Upper','Armor_1100_Lower',
    'Armor_015_Head','Armor_015_Upper','Armor_015_Lower',
    'Armor_1156_Head',
    'Armor_155_Lower', 'Armor_159_Lower',
    'Armor_124_Head',
    'Armor_128_Head',
    'Armor_136_Head',
    'Armor_132_Head',
    'Armor_1065_Head','Armor_1065_Upper','Armor_1065_Lower',
    'Armor_1010_Head','Armor_1010_Upper','Armor_1010_Lower',
    'Armor_1075_Head','Armor_1075_Upper','Armor_1075_Lower',
    'Armor_079_Head','Armor_079_Upper','Armor_079_Lower',
    'Armor_169_Head',    'Armor_189_Head',    'Armor_193_Head',    'Armor_197_Head',
    'Armor_224_Head',
    'Armor_1304_Head','Armor_1304_Upper','Armor_1304_Lower',
    'Armor_171_Head','Armor_171_Upper','Armor_171_Lower', 
    'Armor_173_Head',
    'Armor_180_Head','Armor_180_Upper','Armor_180_Lower',
    'Armor_1086_Head','Armor_1086_Upper','Armor_1086_Lower',
    'Armor_160_Head','Armor_160_Upper','Armor_160_Lower',
    'Armor_115_Head', #Thunder Helm
    'Armor_1150_Upper', #Thunder Helmet
    'Armor_022_Head', #Bokoblin Mask
    'Armor_045_Head', #Moblin Mask
    'Armor_055_Head', #Lizalfos Mask
    'Armor_056_Head', #Lynel Mask
    'Armor_1076_Head',# Cece Hat
    'Armor_1125_Head', #Homblin Mask
    'Armor_178_Head', #Zant's Helmet
    'Armor_174_Head','Armor_174_Upper','Armor_174_Lower', # Tingle's Hood / Tingle's Shirt / Tingle's Tights
    'Armor_177_Head', #Ravio's Hood
    'Armor_1044_Lower', #Archaic Warm Greaves
    'Armor_172_Head', #Majora's Mask
    'Armor_176_Head', #Korok Mask
    'Armor_175_Upper', #Island Lobster Shirt +1
    'Armor_1043_Upper', #Archaic Tunic
    'Armor_1043_Lower', #Archaic Legwear
    'Armor_1151_Head' #Well-Worn Hair Band
    ]

set=0
numInEachSet=28
while set*numInEachSet<len(armors): 
    set+=1
    AddCheat('Armors set %d'%set, '裝備合集%d 慎用!'%set, 1 if set==1 else 2)
    codes=''
    for idx1 in range(numInEachSet):
        idx=(set-1)*numInEachSet+idx1
        codes+=PointerCodeWrite(8, Char2QwordList((armors[idx]+chr(0)*40)[:8])[0], use_D=False, increase=True)
        codes+=PointerCodeWrite(8, Char2QwordList((armors[idx]+chr(0)*40)[8:16])[0], use_D=False, increase=True)
        # codes+=PointerCodeWrite(8, Char2QwordList((armors[idx]+chr(0)*40)[16:24])[0], use_D=False, increase=False)
        if idx>=len(armors)-1: break
        codes+=PointerCodeAddRegister(0x40)
    addoppset=PointerCodeAddRegister(0x50*numInEachSet*(set-1)) if set>1 else ''
    AddCheatCode(PointerCodeHeader(ArmorSlots)+addoppset+codes)
    
def RemoveAllItems(itemPointer, arraySize, fieldLength):
    codes = PointerCodeHeader(itemPointer[:-1],'F')
    codes += PointerCodeCopyRegister('5','F')
    codes += PointerCodeAddOffset(itemPointer[-1],'F')
    codes += PointerCodeAddOffset(itemPointer[-1],'5')
    codes += PointerCodeArithmetic('-','5','5','F')
    codes += PointerCodeAddRegister(fieldLength*arraySize,'F') # F = working address

    # loop for checking whether the item exist, it also record the address of first available item space 
    codes += PointerCodeStartLoop(arraySize)
    codes += PointerCodeArithmetic('-','F','F',fieldLength)
    
    # Check whether the slot is not empty
    codes += PointerCodeCopyRegister('A','F') 
    codes += PointerCodeReadOffset(0,'A',8)
    codes += PointerCodeArithmetic('and','A','A',0xFF)
    codes += PointerCodeCondition('A','!=',0,1) 

    # if yes (empty)
    codes += PointerCodeArithmetic('+','5','5','F')    
    codes += PointerCodeWrite(1,0,register='F',use_D=False,increase=False)
    codes += PointerCodeWrite(1,0,register='5',use_D=False,increase=False)

    codes += PointerCodeEndBlock()

    codes += PointerCodeEndLoop()

    AddCheatCode(codes)

AddCheat('Remove all Armors', '移除所有裝備 慎用!')
RemoveAllItems(ArmorSlots,ArmorMax,0x50)

AddCheat('Show all Koroks on the map', '地圖顯示所有克洛洛')
addr1=AOB('88 76 40 39 1F 05 00 71')
addr2=AOB3(addr1,'68 46 41 39 28 02 00 36')
Hack(addr1,'B %d'%(addr2-addr1),False)



# items=list(range(16,42))+[43,45,46,48,49,51,52,53,55,56]
# for item in items:
    # AddCheat('Add Fabric #%02d'%item, '添加 滑翔傘布料 #%02d'%item)
    # AppendItem(KeySlots, 200, 0x50, 'Obj_SubstituteCloth_%02d'%item)
    # AddCheat('Remove Fabric #%02d'%item, '移除 滑翔傘布料 #%02d'%item)
    # RemoveItem(KeySlots, 200, 0x50, 'Obj_SubstituteCloth_%02d'%item)



# Locations=[
    # (369.13, 2386.5, 1752.9, 'Awake Room', '覺醒室'),
    # ]
# for location in Locations:
    # AddCheat('Teleport(L3+R3) - %s'%location[3], '瞬移(L3+R3) - %s'%location[4], 1 if location[3]=='Awake Room' else 2, showOption=False)
    # PointerHack(Player+[0x2B4], [Float2DWord(location[0]), Float2DWord(location[1]), Float2DWord(location[2])], useButton=['L3','R3'])
    # PointerHack(MainMatterRigidBody+[0xA4], Float2DWord(location[0]), useButton=['L3','R3'])
    # PointerHack(MainMatterRigidBody+[0xB4], Float2DWord(location[1]), useButton=['L3','R3'])
    # PointerHack(MainMatterRigidBody+[0xC4], Float2DWord(location[2]), useButton=['L3','R3'])

################################# END #######################################

HackComplete()
